const Select = () => {
  return {
    // MuiSelect: {
    //   styleOverrides: {
    //     outlined: {
    //       border: `2px solid ${theme.palette.charcoal.main}`,
    //     }
    //   }
    // }
  };
};

export default Select;
