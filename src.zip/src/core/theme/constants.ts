const SANS_SERIF = 'sans-serif';

export const FONTS = {
  OPENSANS: ['Open Sans', SANS_SERIF].join(','),
  EXO2: [`'Exo 2'`, SANS_SERIF].join(',')
};
