import VendorRepairOrderComponent from '@components/vendor-repair-order';

const VendorRepairOrder = () => {
  return <VendorRepairOrderComponent />;
};

export default VendorRepairOrder;
