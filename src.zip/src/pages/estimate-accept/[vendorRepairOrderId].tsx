import EstimateAccept from '@components/estimate-accept';

const EstimateAcceptPage = () => {
  return <EstimateAccept />;
};

export default EstimateAcceptPage;
