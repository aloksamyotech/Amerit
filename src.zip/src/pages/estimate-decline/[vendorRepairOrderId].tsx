import EstimateDecline from '@components/estimate-decline';

const EstimateDeclinePage = () => {
  return <EstimateDecline />;
};

export default EstimateDeclinePage;
