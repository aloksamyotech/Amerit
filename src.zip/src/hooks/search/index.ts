import useVendorRepairOrderSearch from './useVendorRepairOrderSearch';

export default useVendorRepairOrderSearch;
