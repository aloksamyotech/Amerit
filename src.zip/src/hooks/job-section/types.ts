export interface LineItemTypes {
  [key: string]: Array<string>;
}
