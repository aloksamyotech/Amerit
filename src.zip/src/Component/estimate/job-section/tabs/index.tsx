import TabsControl from './TabsControl';

export default TabsControl;
