import Box from '@mui/material/Box';

export default function Main({ children }: { children: any }) {
  return <Box>{children}</Box>;
}
