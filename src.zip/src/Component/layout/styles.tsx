export const mainContentContainer = {
  flexGrow: 1,
  minWidth: 0,
  display: 'flex',
  minHeight: '100vh',
  flexDirection: 'column',
  marginBottom: '30px'
};

export const contentContainer = {
  flexGrow: 1,
  width: '100%'
};
