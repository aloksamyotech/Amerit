export const textField = {
  width: '100%',
  '& .MuiOutlinedInput-root': {
    fontSize: '12px'
  }
};

export const inputLabel = {
  position: 'initial',
  marginLeft: '-12px',
  marginBottom: '-5px'
};
