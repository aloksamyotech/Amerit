import Search from './Search';

export default Search;
