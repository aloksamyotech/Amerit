export interface Search {
  userID: string,
  status: string,
  repairOrderNbr?: string,
	vendorWorkOrderNbr?: string,
	location?: string,
  vin?: string,
};