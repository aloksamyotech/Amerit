import Logo from './Logo';

export default Logo;
