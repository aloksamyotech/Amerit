export const textFieldStyle = {
  width: '100%',
  '& .MuiOutlinedInput-root': {
    fontSize: '12px',
  },
};
