import RepairJob from './RepairJob';

export default RepairJob;
