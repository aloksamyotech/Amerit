import DataGrid from './DataGrid';

export default DataGrid;
