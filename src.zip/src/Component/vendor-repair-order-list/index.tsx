import VendorRepairOrderList from './VendorRepairOrderList';

export default VendorRepairOrderList;
