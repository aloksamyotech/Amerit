export default interface Contact {
  principleName: string;
  principleTitle: string;
  primaryName: string;
  primaryPhone: string;
  primaryEmail: string;
  accountName: string;
  accountPhone: string;
  accountEmail: string;
  companyName: string;
  companyPhone: string;
  companyEmail: string;
}
