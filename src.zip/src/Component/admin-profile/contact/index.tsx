import ContactsTab from './Contact';

export default ContactsTab;
