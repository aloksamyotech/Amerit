import Shop from './Shop';

export default Shop;
