export interface Shop {
  [key: string]: string;
}
