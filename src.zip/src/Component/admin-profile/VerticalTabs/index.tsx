import VerticalTabs  from "./VerticalTabs";

export default VerticalTabs;