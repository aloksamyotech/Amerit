export const style = {
  width: '100%',
  '& .MuiOutlinedInput-root': {
    '&:active fieldset': {
      borderColor: 'secondary.main'
    }
  }
};
