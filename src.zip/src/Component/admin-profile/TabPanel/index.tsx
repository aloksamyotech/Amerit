import TabPanel from './TabPanel';

export default TabPanel;
