import { ProfileProgressCircle } from "./ProfileProgressCircle";

export default ProfileProgressCircle;