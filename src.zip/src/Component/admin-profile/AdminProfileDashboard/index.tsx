import AdminProfileDashboard from "./AdminProfileDashboard";

export default AdminProfileDashboard;