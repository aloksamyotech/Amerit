import AdminProfileDashboard from "./AdminProfileDashboard/AdminProfileDashboard";

export default AdminProfileDashboard;