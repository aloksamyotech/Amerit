import VendorRepairOrder from './VendorRepairOrder';

export default VendorRepairOrder;
