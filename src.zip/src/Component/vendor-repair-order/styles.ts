export const formCaption = {
  fontSize: '11px',
  fontWeight: '300'
};

export const formValue = {
  fontSize: '14px',
  fontWeight: '400'
};
