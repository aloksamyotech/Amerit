import EstimateAccept from './EstimateAccept';

export default EstimateAccept;
