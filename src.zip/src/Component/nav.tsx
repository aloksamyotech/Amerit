import Box from '@mui/material/Box';

export default function Nav() {
  return <Box>Nav</Box>;
}
