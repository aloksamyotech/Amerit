export const rows = [
  {
    id: 1,
    Address: '71,Cherry Court SOUTHAMPTON SO53 5PD UkS',
    shopName: 'Speedy Auto Repairs',
    Phone: '020 7946 0000'
  },
  {
    id: 2,
    Address: '71,Cherry Court SOUTHAMPTON SO53 5PD',
    shopName: 'Speedy Auto Repairs',
    Phone: '020 7946 0000'
  },
  {
    id: 3,
    Address: '71,Cherry Court SOUTHAMPTON SO53 5PD UkS',
    shopName: 'Speedy Auto Repairs',
    Phone: '020 7946 0000'
  },
  {
    id: 4,
    Address: '71,Cherry Court SOUTHAMPTON SO53 5PD UkS',
    shopName: 'Speedy Auto Repairs',
    Phone: '020 7946 0000'
  },
  {
    id: 5,
    Address: '71,Cherry Court SOUTHAMPTON SO53 5PD UkS',
    shopName: 'Speedy Auto Repairs',
    Phone: '020 7946 0000'
  },
  {
    id: 6,
    Address: '71,Cherry Court SOUTHAMPTON SO53 5PD UkS',
    shopName: 'Speedy Auto Repairs',
    Phone: '020 7946 0000'
  },
  {
    id: 7,
    Address: '71,Cherry Court SOUTHAMPTON SO53 5PD UkS',
    shopName: 'Speedy Auto Repairs',
    Phone: '020 7946 0000'
  },
  {
    id: 8,
    Address: '71,Cherry Court SOUTHAMPTON SO53 5PD UkS',
    shopName: 'Speedy Auto Repairs',
    Phone: '020 7946 0000'
  }
];
