import Documents from './Documents';

export default Documents;
