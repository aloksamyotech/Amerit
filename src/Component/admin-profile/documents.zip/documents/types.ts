export interface ILinearProgressWithLabel {
  value: number;
}
